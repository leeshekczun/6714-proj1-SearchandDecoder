## Submission.py for COMP6714-Project1

###################################################################################################################
## Question No. 0:
def add(a, b): # do not change the heading of the function
    return a + b




###################################################################################################################
## Question No. 1:

def gallop_to(a, val):# do not change the heading of the function
    pass # **replace** this line with your code


###################################################################################################################
## Question No. 2:

def Logarithmic_merge(index, cut_off, buffer_size): # do not change the heading of the function
    pass # **replace** this line with your code





###################################################################################################################
## Question No. 3:

def decode_gamma(inputs):# do not change the heading of the function
    pass # **replace** this line with your code

def decode_delta(inputs):# do not change the heading of the function
    pass # **replace** this line with your code

def decode_rice(inputs, b):# do not change the heading of the function
    pass # **replace** this line with your code